
################ Begin of user configurable constants section: ################

$path = "/u/sb/.www/cartoons/dilbert/img";
$first = "19990518";
$title = "Dilbert";
$prefix = "dilbert";
$suffix = ".gif";

################# End of user configurable constants section. #################

1;

