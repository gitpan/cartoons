
################ Begin of user configurable constants section: ################

$path = "/u/sb/.www/cartoons/peanuts/img";
$first = "19990511";
$title = "Peanuts";
$prefix = "peanuts";
$suffix = ".gif";

################# End of user configurable constants section. #################

1;

