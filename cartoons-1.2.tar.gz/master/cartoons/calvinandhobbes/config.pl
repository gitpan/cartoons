
################ Begin of user configurable constants section: ################

$path = "/u/sb/.www/cartoons/calvinandhobbes/img";
$first = "19961117";
$title = "Calvin &amp; Hobbes";
$prefix = "calvinandhobbes";
$suffix = ".gif";

################# End of user configurable constants section. #################

1;

