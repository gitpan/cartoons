
################ Begin of user configurable constants section: ################

$path = "/u/sb/.www/cartoons/garfield/img";
$first = "19990508";
$title = "Garfield";
$prefix = "garfield";
$suffix = ".gif";

################# End of user configurable constants section. #################

1;

