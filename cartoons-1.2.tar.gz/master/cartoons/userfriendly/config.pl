
################ Begin of user configurable constants section: ################

$path = "/u/sb/.www/cartoons/userfriendly/img";
$first = "19971117";
$title = "User Friendly";
$prefix = "userfriendly";
$suffix = ".gif";

################# End of user configurable constants section. #################

1;

